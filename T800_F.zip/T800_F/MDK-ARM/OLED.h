#ifndef __OLED_H
#define __OLED_H

#include "stm32f4xx_hal.h"

/*----��������----*/
void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Row, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Row, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Row, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Row, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Row, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Row, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_Display(void);
void OLED_Display_Page1(void);
void OLED_Display_Page2(void);
void OLED_DrawBMP(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, const uint8_t *BMP);
void OLED_Display_Page3(void);
#endif
